import app from './src/app.js'

app.listen(8000, () => {
    console.log('ok');
})